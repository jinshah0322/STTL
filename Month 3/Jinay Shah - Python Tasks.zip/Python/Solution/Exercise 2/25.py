mylist = [1,2,3,4,5,6,7,8,9,10]
last5 = mylist[-5:]
print(last5)
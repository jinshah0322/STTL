a = [1,5,1,4,8,4,5,9,0,5]
print(list(reversed(sorted(a))))
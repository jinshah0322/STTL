odd = [i for i in range(1, 20, 2)]
print(odd)
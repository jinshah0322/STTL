lst = [1,2,3]
lst1 = lst
lst1.append(4)
print(lst)
print(lst1)

my_set = {1, 2, 3}
another_set = my_set
my_set.add(4)
print(my_set)     
print(another_set)

my_set = {1, 2, 3}
another_set = my_set
my_set.add(4)
print(my_set)     
print(another_set)
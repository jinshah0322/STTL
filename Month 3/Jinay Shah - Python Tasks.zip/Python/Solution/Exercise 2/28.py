import string
alphabet_dict = {char: index for index, char in zip(range(1,27),string.ascii_lowercase)}
print(alphabet_dict)
my_list = [1, 2, 3, 4, 5]
first_5_elements_list = my_list[:5]
print("First 5 element of the list:", first_5_elements_list)

my_tuple = (1, 2, 3, 4, 5)
first_5_elements_tuple = my_tuple[:5]
print("First 5 element of the tuple:", first_5_elements_tuple)

my_string = "hello"
first_5_element_string = my_string[:5]
print("First 5 element of the string:", first_5_element_string)
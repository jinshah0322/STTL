string = "Jinay shah"
print(string.lower())
print(string.upper())
print(string.capitalize())
print(string.title())
print(string.swapcase())
my_list = [1, 2, 3, 4, 5]
elements_list = my_list[1:-1]
print("element of the list:", elements_list)

my_tuple = (1, 2, 3, 4, 5)
elements_tuple = my_tuple[1:-1]
print("element of the tuple:", elements_tuple)

my_string = "hello"
element_string = my_string[1:-1]
print("element of the string:", element_string)
a = [i for i in range(1,9)]
b = [i for i in range(4,10)]
c = []
c = set(a).intersection(set(b))
print(c)
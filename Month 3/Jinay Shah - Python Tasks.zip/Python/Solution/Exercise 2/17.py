str = "Jinay Shah Shah"
subsring = "Shah"
print(str.count(subsring))
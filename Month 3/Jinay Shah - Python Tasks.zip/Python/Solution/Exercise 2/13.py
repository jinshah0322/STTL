str = "Jinay Shah"
subSting = " "
split = str.split(" ")
print(split)
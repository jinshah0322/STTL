my_list = [1, 2, 3, 4, 5]
last_element_list = my_list[-1]
print("Last element of the list:", last_element_list)

my_tuple = (1, 2, 3, 4, 5)
last_element_tuple = my_tuple[-1]
print("Last element of the tuple:", last_element_tuple)

my_string = "hello"
last_element_string = my_string[-1]
print("Last element of the string:", last_element_string)
text = "abc123 "
print("isalpha():", text.isalpha())
print("isdigit():", text.isdigit())
print("isalnum():", text.isalnum())
print("isspace():", text.isspace())
print("islower():", text.islower())
print("isupper():", text.isupper())
print("startswith('abc'):", text.startswith("abc"))
print("endswith('123'):", text.endswith("123"))
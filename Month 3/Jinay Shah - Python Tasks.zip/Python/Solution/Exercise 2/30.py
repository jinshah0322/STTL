lst = [i for i in range(1, 11)]
square = [i**2 for i in lst]
print(square)
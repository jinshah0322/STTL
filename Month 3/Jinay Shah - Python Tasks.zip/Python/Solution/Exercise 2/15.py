strings = ["apple", "banana", "orange", "grape"]
substring = " is a fruit,"
result = substring.join(strings)
print(result)
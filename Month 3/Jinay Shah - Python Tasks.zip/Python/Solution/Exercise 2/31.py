lst1 = [1,2,3,4,5]
lst2 = [4,5,6,7]
lst3 = set(lst1).symmetric_difference(set(lst2))
print(lst3)
dict1 = {'a':1,'b':2,'c':3}
dict2 = {'a':4,'d':5,'e':6}

dict1.update(dict2)

print(dict1)
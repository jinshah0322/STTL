dict1 = {'a':4,'d':5,'e':6}
if('a' in dict1.keys()):
    print("key is present")
else:
    print("Not present")
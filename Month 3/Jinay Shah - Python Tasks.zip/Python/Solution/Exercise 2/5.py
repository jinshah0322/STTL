x=(1,2,3,4,5)
y=(4,5,6,7)
z =set(x).symmetric_difference(set(y))
print(z)
str = "Jinay,Shah"
split = str.replace(","," ")
print(split)
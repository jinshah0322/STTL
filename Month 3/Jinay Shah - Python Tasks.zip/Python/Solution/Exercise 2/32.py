def stringChecker(str1):
    return str1.istitle()

str1 = input("Enter a string: ")
print(stringChecker(str1))
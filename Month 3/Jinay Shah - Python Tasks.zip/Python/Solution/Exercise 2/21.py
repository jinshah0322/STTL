my_list = [1, 2, 3, 4, 5]
last_3_elements_list = my_list[-3:]
print("Last 3 element of the list:", last_3_elements_list)

my_tuple = (1, 2, 3, 4, 5)
last_3_elements_tuple = my_tuple[-3:]
print("Last 3 element of the tuple:", last_3_elements_tuple)

my_string = "hello"
last_3_element_string = my_string[-3:]
print("Last 3 element of the string:", last_3_element_string)
str = "Jinay Shah"
name,surname = str.split(" ")
print(name,surname)
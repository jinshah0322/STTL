dictionary = {i:1 for i in range(1,11)}
print(dictionary.keys())  
print(dictionary.values())  
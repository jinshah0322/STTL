import datetime
dtime = datetime.datetime.now()
strDateTime = str(dtime)
print(strDateTime)
print(type(strDateTime))
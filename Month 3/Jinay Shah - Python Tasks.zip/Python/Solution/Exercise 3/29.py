import random
num = random.randint(0,100)
print(num)
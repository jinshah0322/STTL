from mod import MyClass, outside_method
obj = MyClass("Alice")
obj.greet()
obj.leave()
print("Counter:", obj.counter)
outside_method()
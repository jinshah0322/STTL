import datetime
print(datetime.datetime.now())
print(datetime.date.today())
file = open("test_file.txt","w")
file.write("Hello World")
file.close()
file = open("test_file.txt", "r")
print(file.read())
import random
nums = random.sample(range(1,101),4)
print(nums)
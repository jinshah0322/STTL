# if True
#     print("Hello")


#  print("Hello")


# print(my_variable)


# result = 10 + "5"
# print(result)

number = int("abc")
print(number)
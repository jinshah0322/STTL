lst = [1,2,3]
if(len(lst)<5):
    raise Exception("Minimum length of list should be 5")
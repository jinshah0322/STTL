file = open("test_file.txt", "a")
file.write("fine?")
file.close()
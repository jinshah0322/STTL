i = 10
while(i>0):
    if(i%2!=0):
        print(i)
    i-=1
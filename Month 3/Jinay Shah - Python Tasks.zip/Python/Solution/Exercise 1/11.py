a,b,c = map(int,input().split())
print("Maximum number is:",max(a,b,c))
print("Minimum number is:",min(a,b,c))
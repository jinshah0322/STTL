a = int(input("Enter number 1:"))
b = int(input("Enter number 1:"))

equal_to = a == b

not_equal_to = a != b

greater_than = a > b

less_than = a < b

greater_than_or_equal_to = a >= b

less_than_or_equal_to = a <= b

print("Equal to:", equal_to)
print("Not equal to:", not_equal_to)
print("Greater than:", greater_than)
print("Less than:", less_than)
print("Greater than or equal to:", greater_than_or_equal_to)
print("Less than or equal to:", less_than_or_equal_to)
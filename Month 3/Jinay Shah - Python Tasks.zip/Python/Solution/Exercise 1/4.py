string_variable = "123"
int_variable = int(string_variable)
float_variable = float(string_variable)
bool_variable = bool(string_variable)
print(f"int-{int_variable}\nfloat-{float_variable}\nboolean-{bool_variable}\nstring-{string_variable}")
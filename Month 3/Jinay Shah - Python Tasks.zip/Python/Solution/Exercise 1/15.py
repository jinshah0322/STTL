a = list(map(int,input().split()))
for i in range(0,3):
    print(a[i])
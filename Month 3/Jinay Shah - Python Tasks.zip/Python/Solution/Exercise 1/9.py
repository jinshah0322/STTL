a = True
b = False

logical_and = a and b

logical_or = a or b

logical_not_a = not a
logical_not_b = not b

print("Logical AND:", logical_and)
print("Logical OR:", logical_or)
print("Logical NOT of a:", logical_not_a)
print("Logical NOT of b:", logical_not_b)
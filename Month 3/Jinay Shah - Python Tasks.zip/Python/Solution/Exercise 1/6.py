a = float(input("Enter number 1:"))
b = float(input("Enter number 2:"))

addition = a + b
subtraction = a - b
multiplication = a * b
division = a / b
floor_division = a // b
modulo = a % b
exponentiation = a ** b

print("Addition:", addition)
print("Subtraction:", subtraction)
print("Multiplication:", multiplication)
print("Division:", division)
print("Floor Division:", floor_division)
print("Modulo:", modulo)
print("Exponentiation:", exponentiation)
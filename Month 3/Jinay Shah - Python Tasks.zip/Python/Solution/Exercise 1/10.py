a = int(input("Enter number 1:"))
b = int(input("Enter number 2:"))
c = int(input("Enter number 3:"))

print("Maximum number is:",max(a,b,c))
print("Minimum number is:",min(a,b,c))
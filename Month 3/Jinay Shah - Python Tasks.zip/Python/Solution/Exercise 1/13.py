for i in range(10,-1,-1):
    if(i%2!=0):
        print(i)
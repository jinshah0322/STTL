import random
print(sum([random.randint(1,101) for _ in range(15)]))
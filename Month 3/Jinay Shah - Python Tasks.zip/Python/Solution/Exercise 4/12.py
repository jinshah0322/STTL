bin = "11010001111100111"
print(int(bin,2))
print(hex(int(bin,2)))
print(oct(int(bin,2)))
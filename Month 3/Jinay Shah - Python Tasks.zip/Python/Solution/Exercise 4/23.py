lst1 = [1,2,3]
lst2 = [4,5,6]
result = list(map(lambda x,y:x*y,lst1,lst2))
print(result)
octal = str(13)
print(bin(int(octal,8)))
print(int(octal,8))
print(hex(int(octal,8)))
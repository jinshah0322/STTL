num1,num2 = map(int,input().split())
print(max(num1,num2))
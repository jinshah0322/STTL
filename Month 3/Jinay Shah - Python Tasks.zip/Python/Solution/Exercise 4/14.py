negativeNumber = int(input("Enter any negative number:"))
print(abs(negativeNumber))
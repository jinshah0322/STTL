decimal = 15
print(bin(decimal))
print(hex(decimal))
print(oct(decimal))
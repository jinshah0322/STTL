lst = [i**2 for i in range(1,26)]
print(lst)
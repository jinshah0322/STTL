lst = [i for i in range(1,11)]
cube = map(lambda x:x**3,lst)
print(list(cube))
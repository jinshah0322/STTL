lst = [i*2+11 for i in range(1,11)]
print(lst)
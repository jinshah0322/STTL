lst = [i*2 for i in range(1,51)]
print(lst)
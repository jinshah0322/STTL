import random
lst = [random.randint(1,101) for _ in range(1,11)]
print(min(lst))
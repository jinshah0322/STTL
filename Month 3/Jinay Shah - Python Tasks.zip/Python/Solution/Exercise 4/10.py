hexadecimal = str(10)
print(bin(int(hexadecimal,16)))
print(int(hexadecimal,16))
print(oct(int(hexadecimal,16)))
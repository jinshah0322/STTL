divisor, remainder = divmod(5, 2)
print(divisor,remainder)
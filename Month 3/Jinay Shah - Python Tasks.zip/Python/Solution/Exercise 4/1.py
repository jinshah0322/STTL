result = lambda num,exponent:num**exponent
num = int(input())
exponent = int(input())
print(result(num,exponent))
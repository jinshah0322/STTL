arr = list(map(int,input().split()))
result = []
while(len(arr)>0):
    result.append(arr.pop())

print(result)
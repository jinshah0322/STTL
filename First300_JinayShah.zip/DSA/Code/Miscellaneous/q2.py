string = input()
if(string[::-1] == string):
    print("It is palindrome")
else:
    print("It is not palindrome")
input_array = [3, 1, 4, 4, 2, 2, 1, 5, 3]
input_array.sort()
k = int(input())
print(input_array)
print(input_array[k-1])
#include<stdio.h>
#define pie 3.14
void main(){
    float r;
    scanf("%f",&r);
    printf("%f",pie*r*r);
}
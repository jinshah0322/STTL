import calendar
year = int(input())
month = int(input())
print(calendar.month(year,month))
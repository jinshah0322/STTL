import os
userInput = input("Jinay>>")
os.system(f"echo {userInput}")
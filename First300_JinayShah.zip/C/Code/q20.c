#include<stdio.h>
void main(){
    float f,c;
    scanf("%f",&f);
    c = 5*(f-32)/9;
    printf("%f degree celcius",c);
}   
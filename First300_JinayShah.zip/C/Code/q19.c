#include<stdio.h>
void main(){
    float c,f;
    scanf("%f",&c);
    f=(9*c/5)+32;
    printf("%f degree farhenite",f);
}
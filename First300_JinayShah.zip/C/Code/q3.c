#include<stdio.h>
void main(){
    int a;
    scanf("%d",&a);
    if(a%2==0){
        printf("It is even");
    } else{
        printf("It is odd");
    }
}
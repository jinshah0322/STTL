#include<stdio.h>
void main(){
    char character;
    scanf("%c",&character);
    printf("%d",character);
}   
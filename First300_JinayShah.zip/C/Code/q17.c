#include<stdio.h>
void main(){
    float base,height;
    scanf("%f %f",&base,&height);
    printf("%f",0.5*base*height);
}
pound = 0
miles=0
km = float(input("Enter km:"))
print(f"Converted value of {km}km into miles is {km*0.62137119}")
kg = float(input("Enter kg:"))
print(f"Converted value of {kg}kg into pound is {kg*2.20462}")
#include<stdio.h>
void main(){
    float l,b;
    scanf("%f %f",&l,&b);
    printf("%f",l*b);
}
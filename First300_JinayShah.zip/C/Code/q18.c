#include<stdio.h>
void main(){
    float p,r;
    int n;
    scanf("%f %f %d",&p,&r,&n);
    printf("interest = %f",p*r*n/100);
}